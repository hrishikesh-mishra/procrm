<?php
$module_name = 'alan_communicationlog';
$listViewDefs [$module_name] = 
array (
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => true,
  ),
  'COMMUNICATION_TYPE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_COMMUNICATION_TYPE',
    'width' => '10%',
    'default' => true,
  ),
  'FUNCTION_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_FUNCTION_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'OBJECT_TYPE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_OBJECT_TYPE',
    'width' => '10%',
    'default' => true,
  ),
  'OBJECT_ID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_OBJECT_ID',
    'width' => '10%',
    'default' => true,
  ),
  'STATUS' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_STATUS',
    'width' => '10%',
    'default' => true,
  ),
);
?>
