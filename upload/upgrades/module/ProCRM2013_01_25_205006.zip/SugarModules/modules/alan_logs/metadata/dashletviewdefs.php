<?php
$dashletData['alan_logsDashlet']['searchFields'] = array (
);
$dashletData['alan_logsDashlet']['columns'] = array (
);
