<?php
$dashletData['alan_OrderAddressDashlet']['searchFields'] = array (
);
$dashletData['alan_OrderAddressDashlet']['columns'] = array (
);
