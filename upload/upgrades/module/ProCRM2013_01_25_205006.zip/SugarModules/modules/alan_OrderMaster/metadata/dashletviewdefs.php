<?php
$dashletData['alan_OrderMasterDashlet']['searchFields'] = array (
);
$dashletData['alan_OrderMasterDashlet']['columns'] = array (
);
