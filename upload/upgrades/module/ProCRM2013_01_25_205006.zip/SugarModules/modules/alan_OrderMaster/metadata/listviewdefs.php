<?php
$module_name = 'alan_OrderMaster';
$listViewDefs [$module_name] = 
array (
  'ORDERDATE' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_ORDERDATE',
    'width' => '10%',
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'ORDERVALUE' => 
  array (
    'type' => 'float',
    'label' => 'LBL_ORDERVALUE',
    'width' => '10%',
    'default' => true,
  ),
  'PAYMENTDATE' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_PAYMENTDATE',
    'width' => '10%',
    'default' => true,
  ),
  'PAYMENTMETHOD' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PAYMENTMETHOD',
    'width' => '10%',
    'default' => true,
  ),
  'PAYMENTSTATUS' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PAYMENTSTATUS',
    'width' => '10%',
    'default' => true,
  ),
);
?>
