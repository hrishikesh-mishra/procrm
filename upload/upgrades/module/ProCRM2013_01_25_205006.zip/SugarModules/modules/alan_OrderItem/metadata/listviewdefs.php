<?php
$module_name = 'alan_OrderItem';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'ITEMNO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_ITEMNO',
    'width' => '10%',
    'default' => true,
  ),
  'ITEMCODE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ITEMCODE',
    'width' => '10%',
    'default' => true,
  ),
  'COLOR' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_COLOR',
    'width' => '10%',
    'default' => true,
  ),
  'SIZE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SIZE',
    'width' => '10%',
    'default' => true,
  ),
  'ITEMTYPE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ITEMTYPE',
    'width' => '10%',
    'default' => true,
  ),
  'QUANTITY' => 
  array (
    'type' => 'int',
    'label' => 'LBL_QUANTITY',
    'width' => '10%',
    'default' => true,
  ),
  'UNITAMOUNT' => 
  array (
    'type' => 'float',
    'label' => 'LBL_UNITAMOUNT',
    'width' => '10%',
    'default' => true,
  ),
  'DISCOUNTAMOUNT' => 
  array (
    'type' => 'float',
    'label' => 'LBL_DISCOUNTAMOUNT',
    'width' => '10%',
    'default' => true,
  ),
);
?>
