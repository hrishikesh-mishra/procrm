<?php
 // created: 2013-01-25 20:50:06
$layout_defs["alan_OrderMaster"]["subpanel_setup"]['alan_ordermaster_alan_orderitem'] = array (
  'order' => 100,
  'module' => 'alan_OrderItem',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ALAN_ORDERMASTER_ALAN_ORDERITEM_FROM_ALAN_ORDERITEM_TITLE',
  'get_subpanel_data' => 'alan_ordermaster_alan_orderitem',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
