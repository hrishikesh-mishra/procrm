<?php
// created: 2013-01-25 20:50:06
$dictionary["alan_OrderMaster"]["fields"]["alan_ordermaster_alan_orderitem"] = array (
  'name' => 'alan_ordermaster_alan_orderitem',
  'type' => 'link',
  'relationship' => 'alan_ordermaster_alan_orderitem',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ALAN_ORDERMASTER_ALAN_ORDERITEM_FROM_ALAN_ORDERITEM_TITLE',
);
