<?php
// created: 2013-01-25 20:50:06
$dictionary["alan_OrderMaster"]["fields"]["alan_ordermaster_alan_orderaddress"] = array (
  'name' => 'alan_ordermaster_alan_orderaddress',
  'type' => 'link',
  'relationship' => 'alan_ordermaster_alan_orderaddress',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ALAN_ORDERMASTER_ALAN_ORDERADDRESS_FROM_ALAN_ORDERADDRESS_TITLE',
);
