<?php
// created: 2013-01-25 20:50:06
$dictionary["alan_OrderAddress"]["fields"]["alan_ordermaster_alan_orderaddress"] = array (
  'name' => 'alan_ordermaster_alan_orderaddress',
  'type' => 'link',
  'relationship' => 'alan_ordermaster_alan_orderaddress',
  'source' => 'non-db',
  'vname' => 'LBL_ALAN_ORDERMASTER_ALAN_ORDERADDRESS_FROM_ALAN_ORDERMASTER_TITLE',
  'id_name' => 'alan_ordermaster_alan_orderaddressalan_ordermaster_ida',
);
$dictionary["alan_OrderAddress"]["fields"]["alan_ordermaster_alan_orderaddress_name"] = array (
  'name' => 'alan_ordermaster_alan_orderaddress_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ALAN_ORDERMASTER_ALAN_ORDERADDRESS_FROM_ALAN_ORDERMASTER_TITLE',
  'save' => true,
  'id_name' => 'alan_ordermaster_alan_orderaddressalan_ordermaster_ida',
  'link' => 'alan_ordermaster_alan_orderaddress',
  'table' => 'alan_ordermaster',
  'module' => 'alan_OrderMaster',
  'rname' => 'name',
);
$dictionary["alan_OrderAddress"]["fields"]["alan_ordermaster_alan_orderaddressalan_ordermaster_ida"] = array (
  'name' => 'alan_ordermaster_alan_orderaddressalan_ordermaster_ida',
  'type' => 'link',
  'relationship' => 'alan_ordermaster_alan_orderaddress',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_ALAN_ORDERMASTER_ALAN_ORDERADDRESS_FROM_ALAN_ORDERADDRESS_TITLE',
);
